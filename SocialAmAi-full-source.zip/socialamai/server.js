require("dotenv").config();
const express = require("express");
const session = require("express-session");
const SQLiteStoreFactory = require("connect-sqlite3");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const multer = require("multer");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const dataDir = path.resolve(ROOT, "data");
const uploadDir = path.resolve(ROOT, process.env.UPLOAD_DIR || "uploads");
fs.mkdirSync(dataDir, { recursive: true });
fs.mkdirSync(uploadDir, { recursive: true });

const dbFile = process.env.DATABASE_FILE || "./data/socialamai.db";
const dbPath = path.isAbsolute(dbFile) ? dbFile : path.resolve(ROOT, dbFile);
fs.mkdirSync(path.dirname(dbPath), { recursive: true });
const db = new Database(dbPath);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL UNIQUE COLLATE NOCASE,
 email TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL,
 display_name TEXT NOT NULL,
 bio TEXT DEFAULT '',
 avatar TEXT DEFAULT '',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS posts (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 body TEXT NOT NULL,
 image TEXT DEFAULT '',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS likes (
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(user_id, post_id)
);
CREATE TABLE IF NOT EXISTS comments (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
 body TEXT NOT NULL,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS follows (
 follower_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 following_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(follower_id, following_id),
 CHECK(follower_id != following_id)
);
CREATE TABLE IF NOT EXISTS notifications (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 recipient_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 actor_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 type TEXT NOT NULL,
 post_id INTEGER REFERENCES posts(id) ON DELETE CASCADE,
 is_read INTEGER DEFAULT 0,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_posts_created ON posts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_comments_post ON comments(post_id, created_at);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(recipient_id, is_read, created_at DESC);
`);

const SQLiteStore = SQLiteStoreFactory(session);
app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
      imgSrc: ["'self'", "data:", "blob:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: null
    }
  }
}));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: false, limit: "1mb" }));
app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: dataDir }),
  secret: process.env.SESSION_SECRET || "development-only-change-this-session-secret",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true, sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
}));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: "draft-7", legacyHeaders: false });
const postLimiter = rateLimit({ windowMs: 60 * 1000, limit: 20, standardHeaders: "draft-7", legacyHeaders: false });
const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadDir),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      cb(null, `${Date.now()}-${require("crypto").randomBytes(8).toString("hex")}${ext}`);
    }
  }),
  limits: { fileSize: (Number(process.env.MAX_UPLOAD_MB) || 5) * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = ["image/jpeg", "image/png", "image/webp", "image/gif"];
    cb(allowed.includes(file.mimetype) ? null : new Error("Only JPG, PNG, WEBP or GIF images are allowed."), allowed.includes(file.mimetype));
  }
});

app.use("/uploads", express.static(uploadDir, { fallthrough: false, maxAge: "7d" }));
app.use(express.static(path.join(ROOT, "public")));

const clean = (v, max = 500) => String(v || "").trim().slice(0, max);
const publicUser = u => u && ({
  id: u.id, username: u.username, displayName: u.display_name,
  bio: u.bio || "", avatar: u.avatar || "", createdAt: u.created_at
});
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Please sign in to continue." });
  next();
}
function getUser(id) { return db.prepare("SELECT * FROM users WHERE id=?").get(id); }
function notify(recipient, actor, type, postId = null) {
  if (recipient && actor && recipient !== actor) {
    db.prepare("INSERT INTO notifications(recipient_id,actor_id,type,post_id) VALUES(?,?,?,?)")
      .run(recipient, actor, type, postId);
  }
}
function postQuery(where = "", params = []) {
  return db.prepare(`
    SELECT p.id,p.body,p.image,p.created_at,
      u.id AS user_id,u.username,u.display_name,u.avatar,
      (SELECT COUNT(*) FROM likes l WHERE l.post_id=p.id) AS like_count,
      (SELECT COUNT(*) FROM comments c WHERE c.post_id=p.id) AS comment_count,
      EXISTS(SELECT 1 FROM likes l WHERE l.post_id=p.id AND l.user_id=?) AS liked
    FROM posts p JOIN users u ON u.id=p.user_id ${where}
    ORDER BY p.created_at DESC LIMIT 100
  `).all(reqUserIdHolder.value, ...params);
}
const reqUserIdHolder = { value: 0 };

app.get("/api/me", (req, res) => {
  const u = req.session.userId ? getUser(req.session.userId) : null;
  res.json({ user: publicUser(u) });
});

app.post("/api/auth/register", authLimiter, async (req, res) => {
  const username = clean(req.body.username, 24).replace(/^@/, "");
  const email = clean(req.body.email, 120).toLowerCase();
  const displayName = clean(req.body.displayName, 50);
  const password = String(req.body.password || "");
  if (!/^[a-zA-Z0-9_]{3,24}$/.test(username)) return res.status(400).json({ error: "Username must be 3–24 characters (letters, numbers, underscore)." });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Enter a valid email address." });
  if (displayName.length < 2) return res.status(400).json({ error: "Display name must be at least 2 characters." });
  if (password.length < 10) return res.status(400).json({ error: "Password must be at least 10 characters." });
  try {
    const hash = await bcrypt.hash(password, 12);
    const info = db.prepare("INSERT INTO users(username,email,password_hash,display_name) VALUES(?,?,?,?)")
      .run(username, email, hash, displayName);
    req.session.userId = Number(info.lastInsertRowid);
    res.status(201).json({ user: publicUser(getUser(req.session.userId)) });
  } catch (e) {
    if (String(e.code).startsWith("SQLITE_CONSTRAINT")) return res.status(409).json({ error: "That username or email is already registered." });
    res.status(500).json({ error: "Could not create account." });
  }
});

app.post("/api/auth/login", authLimiter, async (req, res) => {
  const identity = clean(req.body.identity, 120);
  const user = db.prepare("SELECT * FROM users WHERE username=? COLLATE NOCASE OR email=? COLLATE NOCASE").get(identity, identity);
  if (!user || !(await bcrypt.compare(String(req.body.password || ""), user.password_hash))) {
    return res.status(401).json({ error: "Incorrect username/email or password." });
  }
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not start session." });
    req.session.userId = user.id;
    res.json({ user: publicUser(user) });
  });
});

app.post("/api/auth/logout", (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("connect.sid", { sameSite: "lax" });
    res.json({ ok: true });
  });
});

app.get("/api/feed", (req, res) => {
  reqUserIdHolder.value = req.session.userId || 0;
  const posts = db.prepare(`
    SELECT p.id,p.body,p.image,p.created_at,
      u.id AS user_id,u.username,u.display_name,u.avatar,
      (SELECT COUNT(*) FROM likes l WHERE l.post_id=p.id) AS like_count,
      (SELECT COUNT(*) FROM comments c WHERE c.post_id=p.id) AS comment_count,
      EXISTS(SELECT 1 FROM likes l WHERE l.post_id=p.id AND l.user_id=?) AS liked
    FROM posts p JOIN users u ON u.id=p.user_id
    ORDER BY p.created_at DESC LIMIT 60
  `).all(reqUserIdHolder.value);
  res.json({ posts });
});

app.post("/api/posts", requireAuth, postLimiter, upload.single("image"), (req, res) => {
  const body = clean(req.body.body, 2000);
  if (!body && !req.file) return res.status(400).json({ error: "Write something or attach an image." });
  const image = req.file ? `/uploads/${req.file.filename}` : "";
  const info = db.prepare("INSERT INTO posts(user_id,body,image) VALUES(?,?,?)").run(req.session.userId, body, image);
  res.status(201).json({ id: Number(info.lastInsertRowid) });
});

app.delete("/api/posts/:id", requireAuth, (req, res) => {
  const post = db.prepare("SELECT * FROM posts WHERE id=?").get(Number(req.params.id));
  if (!post) return res.status(404).json({ error: "Post not found." });
  if (post.user_id !== req.session.userId) return res.status(403).json({ error: "You can only delete your own posts." });
  if (post.image && post.image.startsWith("/uploads/")) {
    const file = path.join(uploadDir, path.basename(post.image));
    if (fs.existsSync(file)) fs.unlinkSync(file);
  }
  db.prepare("DELETE FROM posts WHERE id=?").run(post.id);
  res.json({ ok: true });
});

app.post("/api/posts/:id/like", requireAuth, (req, res) => {
  const post = db.prepare("SELECT * FROM posts WHERE id=?").get(Number(req.params.id));
  if (!post) return res.status(404).json({ error: "Post not found." });
  const exists = db.prepare("SELECT 1 FROM likes WHERE user_id=? AND post_id=?").get(req.session.userId, post.id);
  if (exists) db.prepare("DELETE FROM likes WHERE user_id=? AND post_id=?").run(req.session.userId, post.id);
  else {
    db.prepare("INSERT INTO likes(user_id,post_id) VALUES(?,?)").run(req.session.userId, post.id);
    notify(post.user_id, req.session.userId, "like", post.id);
  }
  res.json({ liked: !exists });
});

app.get("/api/posts/:id/comments", (req, res) => {
  const comments = db.prepare(`
    SELECT c.id,c.body,c.created_at,u.username,u.display_name,u.avatar
    FROM comments c JOIN users u ON u.id=c.user_id WHERE c.post_id=?
    ORDER BY c.created_at ASC LIMIT 100
  `).all(Number(req.params.id));
  res.json({ comments });
});

app.post("/api/posts/:id/comments", requireAuth, (req, res) => {
  const post = db.prepare("SELECT * FROM posts WHERE id=?").get(Number(req.params.id));
  const body = clean(req.body.body, 500);
  if (!post) return res.status(404).json({ error: "Post not found." });
  if (!body) return res.status(400).json({ error: "Comment cannot be empty." });
  db.prepare("INSERT INTO comments(user_id,post_id,body) VALUES(?,?,?)").run(req.session.userId, post.id, body);
  notify(post.user_id, req.session.userId, "comment", post.id);
  res.status(201).json({ ok: true });
});

app.get("/api/users/search", requireAuth, (req, res) => {
  const q = clean(req.query.q, 40);
  if (q.length < 2) return res.json({ users: [] });
  const users = db.prepare(`
    SELECT u.id,u.username,u.display_name,u.avatar,u.bio,
      EXISTS(SELECT 1 FROM follows f WHERE f.follower_id=? AND f.following_id=u.id) AS following
    FROM users u WHERE u.id!=? AND (u.username LIKE ? OR u.display_name LIKE ?)
    ORDER BY u.username LIMIT 20
  `).all(req.session.userId, req.session.userId, `%${q}%`, `%${q}%`);
  res.json({ users });
});

app.get("/api/users/:username", (req, res) => {
  const user = db.prepare("SELECT * FROM users WHERE username=? COLLATE NOCASE").get(clean(req.params.username, 24));
  if (!user) return res.status(404).json({ error: "User not found." });
  const viewer = req.session.userId || 0;
  const counts = db.prepare(`
    SELECT (SELECT COUNT(*) FROM posts WHERE user_id=?) AS posts,
    (SELECT COUNT(*) FROM follows WHERE following_id=?) AS followers,
    (SELECT COUNT(*) FROM follows WHERE follower_id=?) AS following,
    EXISTS(SELECT 1 FROM follows WHERE follower_id=? AND following_id=?) AS is_following
  `).get(user.id, user.id, user.id, viewer, user.id);
  const posts = db.prepare(`
    SELECT p.id,p.body,p.image,p.created_at,u.id AS user_id,u.username,u.display_name,u.avatar,
      (SELECT COUNT(*) FROM likes WHERE post_id=p.id) AS like_count,
      (SELECT COUNT(*) FROM comments WHERE post_id=p.id) AS comment_count,
      EXISTS(SELECT 1 FROM likes WHERE post_id=p.id AND user_id=?) AS liked
    FROM posts p JOIN users u ON u.id=p.user_id WHERE p.user_id=? ORDER BY p.created_at DESC LIMIT 60
  `).all(viewer, user.id);
  res.json({ user: publicUser(user), counts, posts });
});

app.post("/api/users/:id/follow", requireAuth, (req, res) => {
  const target = Number(req.params.id);
  if (target === req.session.userId) return res.status(400).json({ error: "You cannot follow yourself." });
  if (!getUser(target)) return res.status(404).json({ error: "User not found." });
  const exists = db.prepare("SELECT 1 FROM follows WHERE follower_id=? AND following_id=?").get(req.session.userId, target);
  if (exists) db.prepare("DELETE FROM follows WHERE follower_id=? AND following_id=?").run(req.session.userId, target);
  else {
    db.prepare("INSERT INTO follows(follower_id,following_id) VALUES(?,?)").run(req.session.userId, target);
    notify(target, req.session.userId, "follow");
  }
  res.json({ following: !exists });
});

app.patch("/api/profile", requireAuth, (req, res) => {
  const displayName = clean(req.body.displayName, 50);
  const bio = clean(req.body.bio, 180);
  if (displayName.length < 2) return res.status(400).json({ error: "Display name must be at least 2 characters." });
  db.prepare("UPDATE users SET display_name=?,bio=? WHERE id=?").run(displayName, bio, req.session.userId);
  res.json({ user: publicUser(getUser(req.session.userId)) });
});

app.post("/api/profile/avatar", requireAuth, upload.single("image"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "Choose an image." });
  const avatar = `/uploads/${req.file.filename}`;
  db.prepare("UPDATE users SET avatar=? WHERE id=?").run(avatar, req.session.userId);
  res.json({ avatar });
});

app.get("/api/notifications", requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT n.id,n.type,n.is_read,n.created_at,n.post_id,u.username,u.display_name
    FROM notifications n JOIN users u ON u.id=n.actor_id
    WHERE n.recipient_id=? ORDER BY n.created_at DESC LIMIT 30
  `).all(req.session.userId);
  db.prepare("UPDATE notifications SET is_read=1 WHERE recipient_id=?").run(req.session.userId);
  res.json({ notifications: rows });
});

app.use((err, req, res, next) => {
  console.error(err);
  if (err instanceof multer.MulterError) return res.status(400).json({ error: err.message });
  if (err.message && err.message.startsWith("Only JPG")) return res.status(400).json({ error: err.message });
  res.status(500).json({ error: "Something went wrong. Please try again." });
});
app.get("*", (req, res) => res.sendFile(path.join(ROOT, "public", "index.html")));

app.listen(PORT, () => console.log(`SocialAmAi running at http://localhost:${PORT}`));
