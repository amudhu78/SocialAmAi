# SocialAmAi

A full-stack social networking MVP built with Node.js, Express, SQLite and vanilla HTML/CSS/JavaScript.

## Included
- Email/username + password registration and login
- Session-based authentication with SQLite-backed sessions
- Text and image posts, delete-own-post
- Like/unlike, comments
- People search, follow/unfollow
- User profile and avatar upload
- Notifications for likes, comments and follows
- Responsive premium dark interface and light-theme toggle
- SQLite persistence

## Requirements
- Node.js 20 or newer
- npm

## Run locally
1. Extract the project ZIP.
2. Open a terminal in the `socialamai` folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Copy `.env.example` to `.env`.
5. Set a unique session secret in `.env` (32+ random characters).
6. Start:
   ```bash
   npm start
   ```
7. Visit `http://localhost:3000`.

For development with automatic restart: `npm run dev`.

## Important production notes
This is a functional MVP starter, not a fully audited production social network. Before inviting the public:
- Use HTTPS and set a strong `SESSION_SECRET`.
- Use a persistent disk or managed database. SQLite and local uploads require persistent storage; many serverless hosts have ephemeral filesystems.
- For multi-instance hosting, move sessions to a shared store (e.g. managed Redis) and database to managed PostgreSQL; move uploads to object storage (S3-compatible).
- Add email verification, password reset, account deletion/export, moderation/report/block tools, content scanning, spam controls and admin tooling.
- Add CSRF protection appropriate to your deployment, stronger abuse/rate controls, audit logging, backups and monitoring.
- Validate uploaded file contents (not only MIME headers), scan uploads, enforce image dimensions and consider re-encoding images.
- Review privacy policy, terms, community rules, data retention and applicable local laws.
- Configure trusted proxy settings and secure cookies correctly if behind a reverse proxy.

## Deploy to a Node host
Recommended for this SQLite/local-upload starter: a host that supports a persistent disk, such as a small VPS or a persistent-volume service.
1. Push this project to a private GitHub repository. Do not commit `.env`, database files or uploads.
2. Create a Node web service from the repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Set environment variables:
   - `NODE_ENV=production`
   - `SESSION_SECRET=<long-random-secret>`
   - `PORT` is normally supplied by the host
   - `DATABASE_FILE=/data/socialamai.db` (if persistent disk is mounted at `/data`)
   - `UPLOAD_DIR=/data/uploads`
6. Attach a persistent disk and mount it at `/data`.
7. Deploy, then open the host-provided HTTPS URL.
8. Test registration, login, image upload, post creation, likes, comments, follow and notifications.

## Deploy to Render (persistent disk)
- Create a new **Web Service** from your GitHub repository.
- Runtime: Node; Build: `npm install`; Start: `npm start`.
- Add a persistent disk mounted at `/data`.
- Add `NODE_ENV=production`, `SESSION_SECRET`, `DATABASE_FILE=/data/socialamai.db`, `UPLOAD_DIR=/data/uploads`.
- Deploy and use the generated `onrender.com` URL.
- Note: free/ephemeral instances may not provide persistent disks; choose a plan that supports one or migrate to managed database/object storage.

## Deploy to a serverless platform
Do not deploy this exact SQLite/local-file configuration unchanged to a serverless filesystem. First migrate SQLite to managed PostgreSQL, sessions to a shared store, and image uploads to object storage; then configure the platform's Node runtime and environment variables.

## API overview
- `GET /api/me`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/feed`
- `POST /api/posts` (multipart form: `body`, optional `image`)
- `DELETE /api/posts/:id`
- `POST /api/posts/:id/like`
- `GET /api/posts/:id/comments`
- `POST /api/posts/:id/comments`
- `GET /api/users/search?q=...`
- `GET /api/users/:username`
- `POST /api/users/:id/follow`
- `PATCH /api/profile`
- `POST /api/profile/avatar` (multipart `image`)
- `GET /api/notifications`

## Project structure
```
socialamai/
  server.js
  package.json
  .env.example
  README.md
  public/
    index.html
    styles.css
    app.js
```
