const $ = (id) => document.getElementById(id);
let me = null, authMode = "login", activeView = "home", searchTimer;
const esc = (s="") => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const initials = name => (name || "S").trim().slice(0,1).toUpperCase();
function avatar(url, name, cls="avatar") {
  return `<div class="${cls}">${url ? `<img src="${esc(url)}" alt="">` : esc(initials(name))}</div>`;
}
async function api(url, options={}) {
  const opts={credentials:"same-origin",...options,headers:{...(options.headers||{})}};
  if(opts.body && !(opts.body instanceof FormData)) { opts.headers["Content-Type"]="application/json"; opts.body=JSON.stringify(opts.body); }
  const r=await fetch(url,opts); let data={}; try{data=await r.json()}catch{}
  if(!r.ok) throw new Error(data.error || "Request failed."); return data;
}
function toast(msg){$("toast").textContent=msg;$("toast").style.display="block";clearTimeout(toast.timer);toast.timer=setTimeout(()=>$("toast").style.display="none",2400)}
function timeAgo(value){const d=new Date(value.replace(" ","T")+"Z"),s=Math.max(0,(Date.now()-d.getTime())/1000);if(s<60)return "just now";if(s<3600)return `${Math.floor(s/60)}m ago`;if(s<86400)return `${Math.floor(s/3600)}h ago`;return `${Math.floor(s/86400)}d ago`}
function updateIdentity(){
 const name=me?.displayName||"Guest creator",handle=me?`@${me.username}`:"@guest";
 $("sideName").textContent=name;$("sideHandle").textContent=handle;
 $("sideAvatar").innerHTML=me?.avatar?`<img src="${esc(me.avatar)}">`:esc(initials(name));
 $("composerAvatar").innerHTML=$("sideAvatar").innerHTML;
 $("headerAvatar").innerHTML=me?.avatar?`<img src="${esc(me.avatar)}">`:esc(initials(name));
}
function openAuth(mode="login"){authMode=mode;$("authModal").classList.add("open");setAuthMode(mode)}
function setAuthMode(mode){
 authMode=mode;document.querySelectorAll("[data-auth]").forEach(b=>b.classList.toggle("selected",b.dataset.auth===mode));
 $("authTitle").textContent=mode==="login"?"Welcome back.":"Join your community.";
 $("authSubtitle").textContent=mode==="login"?"Sign in to your SocialAmAi community.":"Create an account and find your people.";
 $("nameField").hidden=mode!=="register";$("usernameField").hidden=mode!=="register";$("emailField").hidden=mode!=="register";
 $("identityLabel").textContent=mode==="login"?"Email or username":"Contact email";
 $("authForm").elements.identity.required=mode==="login";$("authForm").elements.identity.placeholder=mode==="login"?"you@example.com":"Optional for registration";
 $("authForm").elements.email.required=mode==="register";
 $("authForm").elements.username.required=mode==="register";
 $("authForm").elements.displayName.required=mode==="register";
 $("authSubmit").textContent=mode==="login"?"Sign in →":"Create account →";$("authError").textContent="";
}
document.querySelectorAll("[data-auth]").forEach(b=>b.addEventListener("click",()=>setAuthMode(b.dataset.auth)));
$("authClose").onclick=()=>$("authModal").classList.remove("open");
$("authModal").addEventListener("click",e=>{if(e.target===$("authModal"))$("authModal").classList.remove("open")});
$("authForm").addEventListener("submit",async e=>{
 e.preventDefault();const f=new FormData(e.currentTarget),payload=Object.fromEntries(f.entries());
 try{
  const data=authMode==="login"?await api("/api/auth/login",{method:"POST",body:{identity:payload.identity,password:payload.password}}):await api("/api/auth/register",{method:"POST",body:{username:payload.username,email:payload.email,displayName:payload.displayName,password:payload.password}});
  me=data.user;$("authModal").classList.remove("open");e.currentTarget.reset();updateIdentity();toast("Welcome to SocialAmAi!");await renderView("home");
 }catch(err){$("authError").textContent=err.message}
});
async function ensureAuth(){if(!me){openAuth();return false}return true}
function postCard(p){
 const mine=me&&me.id===p.user_id;
 return `<article class="post" data-post="${p.id}"><div class="post-head">${avatar(p.avatar,p.display_name)}<div class="post-author"><b>${esc(p.display_name)} ${mine?'<span class="subtle">· you</span>':""}</b><small>@${esc(p.username)} · ${timeAgo(p.created_at)}</small></div>${mine?`<button class="post-menu" data-delete="${p.id}" title="Delete post">⋯</button>`:""}</div>${p.body?`<div class="post-body">${esc(p.body)}</div>`:""}${p.image?`<img class="post-image" src="${esc(p.image)}" alt="Post image" loading="lazy">`:""}<div class="post-stats">${p.like_count} likes · ${p.comment_count} comments</div><div class="post-actions"><button class="post-action ${p.liked?"liked":""}" data-like="${p.id}">${p.liked?"♥":"♡"} Like</button><button class="post-action" data-comments="${p.id}">▤ Comment</button><button class="post-action" data-share="${p.id}">↗ Share</button></div><div class="comments" id="comments-${p.id}"><div class="comment-items"></div><form class="comment-form" data-comment-form="${p.id}"><input name="body" maxlength="500" placeholder="Write a thoughtful comment..." required><button>Send</button></form></div></article>`;
}
async function renderFeed(target=$("feed")){
 try{const {posts}=await api("/api/feed");target.innerHTML=posts.length?posts.map(postCard).join(""):`<div class="empty-state">✨ Your feed is waiting for its first story.<br>Be the first to share a moment.</div>`}
 catch(e){target.innerHTML=`<div class="empty-state">${esc(e.message)}</div>`}
}
async function showComments(id){
 const box=$(`comments-${id}`);box.classList.toggle("open");if(!box.classList.contains("open"))return;
 const {comments}=await api(`/api/posts/${id}/comments`);
 box.querySelector(".comment-items").innerHTML=comments.length?comments.map(c=>`<div class="comment-row"><b>${esc(c.display_name)}</b>${esc(c.body)}</div>`).join(""):`<div class="comment-row">No comments yet. Start the conversation.</div>`;
}
document.addEventListener("click",async e=>{
 const like=e.target.closest("[data-like]");if(like){if(!await ensureAuth())return;try{await api(`/api/posts/${like.dataset.like}/like`,{method:"POST"});await renderFeed()}catch(x){toast(x.message)}}
 const comments=e.target.closest("[data-comments]");if(comments){try{if(!await ensureAuth())return;await showComments(comments.dataset.comments)}catch(x){toast(x.message)}}
 const del=e.target.closest("[data-delete]");if(del){if(!confirm("Delete this post?"))return;try{await api(`/api/posts/${del.dataset.delete}`,{method:"DELETE"});toast("Post deleted");await renderView(activeView)}catch(x){toast(x.message)}}
 const share=e.target.closest("[data-share]");if(share){const url=location.origin+`/#post-${share.dataset.share}`;try{await navigator.clipboard.writeText(url);toast("Post link copied")}catch{toast(url)}}
 const follow=e.target.closest("[data-follow]");if(follow){if(!await ensureAuth())return;try{await api(`/api/users/${follow.dataset.follow}/follow`,{method:"POST"});await renderView(activeView)}catch(x){toast(x.message)}}
 const view=e.target.closest("[data-view]");if(view){e.preventDefault();renderView(view.dataset.view)}
});
document.addEventListener("submit",async e=>{
 if(e.target.matches("[data-comment-form]")){e.preventDefault();if(!await ensureAuth())return;const id=e.target.dataset.commentForm,body=new FormData(e.target).get("body");try{await api(`/api/posts/${id}/comments`,{method:"POST",body:{body}});e.target.reset();await showComments(id)}catch(x){toast(x.message)}}
});
$("focusComposer").onclick=async()=>{if(!await ensureAuth())return;$("postForm").parentElement.classList.add("expanded");$("postBody").focus()};
$("postBody").addEventListener("focus",()=>$("postForm").parentElement.classList.add("expanded"));
$("postImage").onchange=e=>$("fileName").textContent=e.target.files[0]?.name||"";
$("postForm").addEventListener("submit",async e=>{
 e.preventDefault();if(!await ensureAuth())return;
 const body=$("postBody").value.trim(),file=$("postImage").files[0];if(!body&&!file)return toast("Write something or attach a photo.");
 const form=new FormData();form.append("body",body);if(file)form.append("image",file);
 try{await api("/api/posts",{method:"POST",body:form});$("postForm").reset();$("fileName").textContent="";$("postForm").parentElement.classList.remove("expanded");toast("Your post is live!");await renderView("home")}catch(x){toast(x.message)}
});
$("refreshFeed").onclick=()=>renderFeed();$("signOutBtn").onclick=async()=>{if(!me)return;await api("/api/auth/logout",{method:"POST"});me=null;updateIdentity();toast("Signed out");await renderView("home")};
$("themeToggle").onclick=()=>document.body.classList.toggle("light");
document.querySelectorAll(".outline-btn[data-view]").forEach(b=>b.addEventListener("click",()=>renderView(b.dataset.view)));
async function renderView(view){
 activeView=view;document.querySelectorAll(".nav-item[data-view]").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
 const main=$("mainContent");
 if(view==="home"){main.innerHTML=`<section class="welcome"><span class="eyebrow">A LITTLE MORE CONNECTED</span><h1>Your people.<br><em>Your moments.</em></h1><p>A fresh space to share ideas, celebrate wins and connect with your community.</p></section><section class="composer card"><div class="composer-top">${avatar(me?.avatar,me?.displayName||"G")}<button class="composer-prompt" id="focusComposer">What's on your mind today?</button></div><form id="postForm"><textarea name="body" id="postBody" maxlength="2000" placeholder="Share a thought, a moment, or something worth celebrating..." required></textarea><div class="composer-bottom"><label class="upload-label">＋ Add photo<input type="file" id="postImage" accept="image/png,image/jpeg,image/webp,image/gif" hidden></label><span id="fileName" class="subtle"></span><button class="primary-btn" type="submit">Share post <span>↗</span></button></div></form></section><div class="feed-heading"><div><span class="eyebrow">THE COMMUNITY</span><h2>Your feed</h2></div><button class="soft-btn" id="refreshFeed">↻ Refresh</button></div><div id="feed" class="feed-list"></div>`;
  $("focusComposer").onclick=async()=>{if(await ensureAuth()){$("postForm").parentElement.classList.add("expanded");$("postBody").focus()}};
  $("postBody").onfocus=()=>$("postForm").parentElement.classList.add("expanded");
  $("postImage").onchange=e=>$("fileName").textContent=e.target.files[0]?.name||"";
  $("postForm").onsubmit=async e=>{e.preventDefault();if(!await ensureAuth())return;const file=$("postImage").files[0],body=$("postBody").value.trim();if(!file&&!body)return;const fd=new FormData();fd.append("body",body);if(file)fd.append("image",file);try{await api("/api/posts",{method:"POST",body:fd});toast("Your post is live!");await renderView("home")}catch(x){toast(x.message)}};
  $("refreshFeed").onclick=()=>renderFeed();await renderFeed();
 } else if(view==="discover"){main.innerHTML=`<span class="eyebrow">MEET YOUR COMMUNITY</span><h1 class="page-title">Discover people</h1><input class="top-search" style="width:100%;height:48px" id="peopleSearch" placeholder="Search by name or username..."><div id="peopleResults" class="people-list" style="margin-top:16px"><div class="empty-state">Search for creators to connect with.</div></div>`; $("peopleSearch").oninput=()=>{clearTimeout(searchTimer);searchTimer=setTimeout(searchPeople,250)};if($("globalSearch").value){$("peopleSearch").value=$("globalSearch").value;searchPeople()}}
 else if(view==="profile"){if(!me){main.innerHTML=`<div class="empty-state">Sign in to view your profile.</div>`;openAuth();return}await showProfile(me.username,true)}
 else if(view==="notifications"){if(!await ensureAuth()){main.innerHTML=`<div class="empty-state">Sign in to see notifications.</div>`;return}main.innerHTML=`<span class="eyebrow">WHAT'S HAPPENING</span><h1 class="page-title">Notifications</h1><div class="notification-list" id="notificationList">Loading...</div>`;try{const {notifications}=await api("/api/notifications");$("notificationList").innerHTML=notifications.length?notifications.map(n=>`<div class="notification-row"><div class="avatar">${esc(initials(n.display_name))}</div><div><b>${esc(n.display_name)}</b> ${n.type==="like"?"liked your post":n.type==="comment"?"commented on your post":"started following you"}<div class="subtle" style="font-size:11px">${timeAgo(n.created_at)}</div></div></div>`).join(""):`<div class="empty-state">You're all caught up. ✨</div>`;$("notifDot").style.display="none"}catch(x){toast(x.message)}}
}
async function searchPeople(){const q=$("peopleSearch")?.value.trim();if(!q||q.length<2){$("peopleResults").innerHTML=`<div class="empty-state">Type at least 2 characters to search.</div>`;return}if(!me){openAuth();return}try{const {users}=await api(`/api/users/search?q=${encodeURIComponent(q)}`);$("peopleResults").innerHTML=users.length?users.map(u=>`<div class="person-row">${avatar(u.avatar,u.display_name)}<div class="person-info"><b>${esc(u.display_name)}</b><small>@${esc(u.username)}</small></div><button class="follow-btn ${u.following?"following":""}" data-follow="${u.id}">${u.following?"Following":"＋ Follow"}</button></div>`).join(""):`<div class="empty-state">No people found. Try another search.</div>`}catch(x){toast(x.message)}}
async function showProfile(username,isMe=false){
 const data=await api(`/api/users/${encodeURIComponent(username)}`),u=data.user,c=data.counts;
 $("mainContent").innerHTML=`<span class="eyebrow">YOUR CORNER OF THE COMMUNITY</span><h1 class="page-title">Profile</h1><section class="profile-hero"><div class="profile-top">${avatar(u.avatar,u.displayName)}<div><h2>${esc(u.displayName)}</h2><p>@${esc(u.username)}</p></div></div><div class="profile-stats"><span><b>${c.posts}</b> posts</span><span><b>${c.followers}</b> followers</span><span><b>${c.following}</b> following</span></div><p class="profile-bio">${esc(u.bio||"No bio added yet.")}</p>${isMe?`<div class="profile-controls"><input id="editDisplay" value="${esc(u.displayName)}" maxlength="50" aria-label="Display name"><textarea id="editBio" maxlength="180" placeholder="A little about you...">${esc(u.bio)}</textarea><button class="primary-btn" id="saveProfile">Save profile</button><label class="upload-label">Change avatar <input id="avatarUpload" type="file" accept="image/*" hidden></label></div>`:`<button class="follow-btn ${c.is_following?"following":""}" data-follow="${u.id}">${c.is_following?"Following":"＋ Follow"}</button>`}</section><h2 style="font:800 21px Manrope;margin:20px 0 13px">Posts</h2><div class="feed-list">${data.posts.length?data.posts.map(postCard).join(""):`<div class="empty-state">No posts yet.</div>`}</div>`;
 if(isMe){$("saveProfile").onclick=async()=>{try{const result=await api("/api/profile",{method:"PATCH",body:{displayName:$("editDisplay").value,bio:$("editBio").value}});me=result.user;updateIdentity();toast("Profile updated")}catch(x){toast(x.message)}};$("avatarUpload").onchange=async e=>{const file=e.target.files[0];if(!file)return;const fd=new FormData();fd.append("image",file);try{const r=await api("/api/profile/avatar",{method:"POST",body:fd});me.avatar=r.avatar;updateIdentity();await showProfile(me.username,true);toast("Avatar updated")}catch(x){toast(x.message)}}}
}
$("globalSearch").addEventListener("keydown",e=>{if(e.key==="Enter"){renderView("discover");setTimeout(()=>{const input=$("peopleSearch");if(input){input.value=e.target.value;searchPeople()}},80)}});
$("notificationBtn").onclick=()=>renderView("notifications");
async function init(){ $("year").textContent=new Date().getFullYear();try{const r=await api("/api/me");me=r.user}catch{}updateIdentity();await renderView("home");if(!me)setTimeout(()=>openAuth("login"),450)}
init();
